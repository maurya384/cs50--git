#include<stdio.h>
#include<cs50.h>
int main(void)
{
    printf("minutes: ");
    int n=GetInt();
    n=n*12;
    printf("bottles: %i",n);
    printf("\n");
}