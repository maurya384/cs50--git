#include<stdio.h>
#include<cs50.h>
#include<math.h>
int main(void)
{
    float n;
    do
    {
        printf("O hai! How much change is owed? \n");
        n=GetFloat();
    }
    while(n<0);
    float fd=n*100;
    int total_cents=(int)round(fd);
    int num_quarters=total_cents/25;
    total_cents=total_cents%25;
    int num_dimes=total_cents/10;
    total_cents=total_cents%10;
    int num_nickels=total_cents/5;
    total_cents=total_cents%5;
    int num_pennies=total_cents;
    int total_coins=num_quarters+num_dimes+num_nickels+num_pennies;
    printf("%i\n",total_coins);
}