#include<stdio.h>
#include<cs50.h>
int main(void)
{
    int n;
    do
    {
        printf("height: ");
        n=GetInt();
    }
    while((n<0)||(n>23));
    int num_hashes=2;
    int num_blanks=n-1;
    int i;
    for(i=1;i<=n;i++)
    {
        int j=1;
        while(j<=num_blanks)
        {
            printf(" ");
            j++;
        }
        num_blanks--;
        j=1;
        while(j<=num_hashes)
        {
            printf("#");
            j++;
        }
        num_hashes++;
        printf("\n");
    }
    
}