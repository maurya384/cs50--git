/**
 * recover.c
 *
 * Computer Science 50
 * Problem Set 4
 *
 * Recovers JPEGs from a forensic image.
 */

/**
 * recover.c
 *
 * Computer Science 50
 * Problem Set 4
 *
 * Recovers JPEGs from a forensic image.
 */
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

int main(int argc, char* argv[])
{
    FILE* input_ptr = fopen("card.raw", "r");
    if (input_ptr == NULL)
    {
        printf("Could not open file card.raw .\n");
        return 1;
    }
    uint8_t block_buffer[512];
    FILE* image = NULL;
    int fileCount = 0;
    char title[8];
    while(fread(block_buffer, 512, 1, input_ptr))
    {
        if (block_buffer[0] == 0xff && block_buffer[1] == 0xd8 && block_buffer[2] == 0xff
        && (block_buffer[3] == 0xe0 || block_buffer[3] == 0xe1))
        {
            if (image != NULL)
            {
                fclose(image);
            }
            sprintf(title,"%03d.jpg", fileCount);
            fileCount++;
            image = fopen(title, "w");
        }
        if (image != NULL)
        {
            fwrite(block_buffer, 512, 1, image);
        }
    }
    if (image != NULL)
    {
        fclose(image);
    }
    fclose(input_ptr);
    return 0;
}

