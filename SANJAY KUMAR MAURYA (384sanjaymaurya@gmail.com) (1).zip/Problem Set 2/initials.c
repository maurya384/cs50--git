#include<stdio.h>
#include<cs50.h>
#include<string.h>
int main(void)
{
    //getting a string from user
    string s=GetString();
    //Length of string
    int l=strlen(s);
    //Printing first character in uppercase
    if((s[0]>=65)&&(s[0]<=90))
    {
        printf("%c",s[0]);
    }
    else
    {
        printf("%c",(s[0]-32));
    }
    //Printing other initials in uppercase
    for(int i=1;i<l;i++)
    {
        if(s[i]==' ')
        {
           if((s[i+1]>=65)&&(s[i+1]<=90))
           {
               printf("%c",s[i+1]);
           }
           else
           {
                printf("%c",(s[i+1]-32));
           }
        }
    }
    printf("\n");
}