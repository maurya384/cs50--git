#include<cs50.h>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
int main(int argc,string argv[])
{
    //Exiting when no argument given or greater than one argument passed
    if(argc!=2)
    {
        printf("enter command line argument \n");
        return 1;
    }
    string k=argv[1];
    int l_k=strlen(k);
    //Checking if given key not consist of alphabetical characters
    for(int i=0;i<l_k;i++)
    {
        if((argv[1][i]<65)||(argv[1][i]>122))
        {
            printf("enter command line argument \n");
            return 1;
        }
    }
    //Getting plaintext
        string p=GetString();
        int l_p=strlen(p);
        int j=0;
        for(int i=0;i<l_p;i++)
        {
            //Encrypting if plaintext is of uppercase
            if((p[i]>=65)&&(p[i]<=90))
            {
                if((k[j%l_k]>=65)&&(k[j%l_k]<=90))
                {
                    int asc=k[j%l_k]-65;
                    p[i]=p[i]-65;
                    p[i]=p[i]+asc;
                    p[i]=p[i]%26;
                    p[i]=p[i]+65;
                }
                if((k[j%l_k]>=97)&&(k[j%l_k]<=122))
                {
                    int asc=k[j%l_k]-97;
                    p[i]=p[i]-65;
                    p[i]=p[i]+asc;
                    p[i]=p[i]%26;
                    p[i]=p[i]+65;
                }
                //Shifting key for encryption
                j++;
            }
             //Encrypting if plaintext is of lowercase
            if((p[i]>=97)&&(p[i]<=122))
            {
                if((k[j%l_k]>=65)&&(k[j%l_k]<=90))
                {
                    int asc=k[j%l_k]-65;
                    p[i]=p[i]-97;
                    p[i]=p[i]+asc;
                    p[i]=p[i]%26;
                    p[i]=p[i]+97;
                }
                if((k[j%l_k]>=97)&&(k[j%l_k]<=122))
                {
                    int asc=k[j%l_k]-97;
                    p[i]=p[i]-97;
                    p[i]=p[i]+asc;
                    p[i]=p[i]%26;
                    p[i]=p[i]+97;
                }
                //Shifting key for encryption
                j++;
            }
            //Printing cyphertext
            printf("%c",p[i]);
        }
        printf("\n");
}
