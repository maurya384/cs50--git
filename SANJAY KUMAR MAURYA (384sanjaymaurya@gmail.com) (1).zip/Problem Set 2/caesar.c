#include<stdio.h>
#include<cs50.h>
#include<string.h>
#include<stdlib.h>
int main(int argc,string argv[])
{
    //Exiting when no argument given or greater than one argument passed
    if(argc!=2)
    {
        printf("enter command line argument \n");
        return 1;
    }
    else
    {
        //Converting passed string in command line argument to integer
        int k = atoi(argv[1]);
        string p=GetString();
        //Getting length of given string
        int l=strlen(p);
        for(int i=0;i<l;i++)
        {
            //Converting into cyphertext
            if((p[i]>=65)&&(p[i]<=90))
            {
               p[i]=p[i]-65;
               p[i]=p[i]+k;
               p[i]=p[i]%26;
               p[i]=p[i]+65;
            }
           if((p[i]>=97)&&(p[i]<=122))
           {
                p[i]=p[i]-97;
                p[i]=p[i]+k;
                p[i]=p[i]%26;
                p[i]=p[i]+97;
           }
           //Printing cyphertext
        printf("%c",p[i]);
        }
    printf("\n");
    }
    
    return 0;
}