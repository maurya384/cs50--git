<p class="lead text-danger">
    <a class="errorTitle" href="http://www.youtube.com/watch?v=a96OF8fhCLU#t=3055" target=_blank>oh, hail!</a>
</p>
<p class="text-danger">
    <?= htmlspecialchars($message) ?>
</p>

<a href="javascript:history.go(-1);">Back</a>