/****************************************************************************
 * dictionary.c
 *
 * Computer Science 50
 * Problem Set 5
 *
 * Implements a dictionary's functionality.
 ***************************************************************************/

#include <stdbool.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include "dictionary.h"


typedef struct word_node
{
    // flag to check if word exists or not
    bool check_word;

    // array for alphabets and special character
    struct word_node* children[27];
}
word_node;

// size of dictionary
unsigned int dictionarySize = 0;

// root_word word_node
struct word_node* root_word = NULL;

/**
 * Returns true if word is in dictionary else false.
 */
bool check(const char* word)
{
    unsigned int letter = '0';
    unsigned int index = 0;
    word_node* nextword_node = root_word;

    // read a word
    while(letter != '\0')
    {
        letter = word[index];

        // switch to lowercase
        if (letter <= 90 && letter >= 65)
        {
            letter +=32;
        }

        // allow alphabets or apostrophe
        if ((letter >= 97 && letter <= 122) || (letter == '\''))
        {
            // apostrophe is placed at the end of the alphabet
            if (letter == '\'')
            {
                letter = 26 + 97;
            }

            if (nextword_node->children[letter - 97] == NULL)
            {
                return false;
            }
            else
            {
                nextword_node = nextword_node->children[letter - 97];
            }
        }
        index++;
    }
    return nextword_node->check_word;
}

/**
 * Loads dictionary into memory.  Returns true if successful else false.
 */
bool load(const char* dictionary)
{
    // open dictionary file in read mode
    FILE* fpr = fopen(dictionary, "r");

    if (fpr == NULL)
    {
        printf("Could not open file.\n");
        return false;
    }
    root_word = (word_node*) malloc(sizeof(word_node));

    unsigned int letter = 0;
    word_node* nextword_node = root_word;

    while (letter != EOF)
    {
        letter = fgetc(fpr);
        if (letter != '\n' && letter != EOF)
        {
            if (letter == '\'')
            {
                letter = 26 + 97;
            }

            if (nextword_node->children[letter - 97] == NULL)
            {
                nextword_node->children[letter - 97]
                    = (word_node*) malloc(sizeof(word_node));
            }
            nextword_node = nextword_node->children[letter - 97];
        }
        // Condition for new word
        else if (letter == '\n')
        {
            nextword_node->check_word = true;
            dictionarySize++;
            nextword_node = root_word;
        }
    }
    fclose(fpr);

    return true;
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    // return dictinary size
    return dictionarySize;
}

/**
 * recursively removes each word_node from memory
 */
void unloadword_node(word_node* nextword_node)
{
    for (int i = 0; i < 26; i++)
    {
        if (nextword_node->children[i] != NULL)
        {
            unloadword_node(nextword_node->children[i]);
        }
    }

    // free this word_node
    free(nextword_node);
}

/**
 * Unloads dictionary from memory.  Returns true if successful else false.
 */
bool unload(void)
{
    // pass root_word word_node to unload dictinary from memory
    unloadword_node(root_word);

    return true;
}
